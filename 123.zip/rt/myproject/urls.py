from django.contrib import admin
from django.urls import path
from webcam import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),  # Главная страница
    path('video_feed/', views.video_feed, name='video_feed'),  # Поток видео
]