from django.http import StreamingHttpResponse
from django.shortcuts import render
import cv2

def index(request):
    """Главная страница с видеопотоком."""
    return render(request, 'webcam/index.html')

def gen(camera):
    """Генерация видеопотока."""
    while True:
        # Чтение кадра с камеры
        ret, frame = camera.read()
        if not ret:
            break
        
        # Преобразование кадра в формат JPEG
        _, jpeg = cv2.imencode('.jpg', frame)
        frame = jpeg.tobytes()

        # Отправка фрейма в виде бинарного потока
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

def video_feed(request):
    """Видеопоток камеры."""
    camera = cv2.VideoCapture(0)
    return StreamingHttpResponse(gen(camera),
                                 content_type='multipart/x-mixed-replace; boundary=frame')
